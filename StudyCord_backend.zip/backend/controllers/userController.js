import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/userModel.js';
import Token from '../models/tokenModel.js';
import { sendEmail } from '../utils/sendEmail.js';
import crypto from 'crypto';

export async function register(req, res) {
  try {
    const { name, email, password } = req.body;
    const existing = await User.findOne({ email });
    if (existing) return res.status(409).json({ error: 'Email already registered' });
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hashed });
    const tokenStr = crypto.randomBytes(24).toString('hex');
    const expiresAt = new Date(Date.now() + 1000*60*60*24);
    await Token.create({ userId: user._id, token: tokenStr, expiresAt });
    await sendEmail({ to: email, subject: 'Verify your StudyCord account', text: `Your token: ${tokenStr}` });
    res.json({ ok: true, message: 'Registered. Check email for verification token.' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}

export async function verify(req,res) {
  const { token } = req.body;
  const doc = await Token.findOne({ token, expiresAt: { $gt: new Date() } });
  if (!doc) return res.status(400).json({ error: 'Invalid or expired token' });
  await User.findByIdAndUpdate(doc.userId, { verified: true });
  await Token.deleteOne({ _id: doc._id });
  res.json({ ok: true, message: 'Account verified' });
}

export async function login(req,res) {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user._id, name: user.name, email: user.email, verified: user.verified } });
}

export async function whoami(req,res) {
  res.json({ user: req.user });
}
