import StudySession from '../models/studySession.js';

export async function createSession(req,res){
  const { title='Session', durationMins=0, startedAt, endedAt } = req.body;
  const doc = await StudySession.create({ userId: req.user._id, title, durationMins, startedAt, endedAt });
  res.json(doc);
}

export async function getSessions(req,res){
  const docs = await StudySession.find({ userId: req.user._id }).sort({ createdAt: -1 });
  res.json(docs);
}

export async function updateSession(req,res){
  const { id } = req.params;
  const updated = await StudySession.findOneAndUpdate({ _id: id, userId: req.user._id }, req.body, { new: true });
  if (!updated) return res.status(404).json({ error: 'Not found' });
  res.json(updated);
}

export async function deleteSession(req,res){
  const { id } = req.params;
  const del = await StudySession.findOneAndDelete({ _id: id, userId: req.user._id });
  if (!del) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
}

export async function getStudiedToday(req,res){
  const start = new Date(); start.setHours(0,0,0,0);
  const end = new Date(); end.setHours(23,59,59,999);
  const agg = await StudySession.aggregate([
    { $match: { userId: req.user._id, startedAt: { $gte: start, $lte: end } } },
    { $group: { _id: null, minutes: { $sum: '$durationMins' } } }
  ]);
  res.json({ minutes: agg[0]?.minutes || 0 });
}

export async function getStudyStats(req,res){
  const agg = await StudySession.aggregate([
    { $match: { userId: req.user._id } },
    { $group: { _id: '$userId', sessions: { $sum: 1 }, totalMinutes: { $sum: '$durationMins' } } }
  ]);
  res.json(agg[0] || { sessions: 0, totalMinutes: 0 });
}
