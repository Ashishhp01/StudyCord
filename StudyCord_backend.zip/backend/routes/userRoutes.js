import { Router } from 'express';
import { register, login, verify, whoami } from '../controllers/userController.js';
import auth from '../middleware/userAuth.js';

const r = Router();
r.post('/register', register);
r.post('/login', login);
r.post('/verify', verify);
r.get('/whoami', auth, whoami);
export default r;
