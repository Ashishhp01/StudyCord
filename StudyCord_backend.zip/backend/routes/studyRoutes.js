import { Router } from 'express';
import auth from '../middleware/userAuth.js';
import { createSession, getSessions, updateSession, deleteSession, getStudiedToday, getStudyStats } from '../controllers/studyController.js';

const r = Router();
r.use(auth);
r.post('/', createSession);
r.get('/', getSessions);
r.put('/:id', updateSession);
r.delete('/:id', deleteSession);
r.get('/today', getStudiedToday);
r.get('/stats', getStudyStats);
export default r;
