import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

import userRoutes from './routes/userRoutes.js';
import studyRoutes from './routes/studyRoutes.js';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 9000;
const MONGO_URI = process.env.MONGO_URI;

app.get('/', (req,res)=> res.json({ ok:true, service:'StudyCord API' }));

app.use('/api/users', userRoutes);
app.use('/api/study', studyRoutes);

async function start() {
  try {
    if (!MONGO_URI) throw new Error('Missing MONGO_URI');
    await mongoose.connect(MONGO_URI);
    console.log('MongoDB connected');
    app.listen(PORT, () => console.log(`Server running on :${PORT}`));
  } catch (e) {
    console.error('Startup error:', e.message);
    process.exit(1);
  }
}
start();
