import React from 'react';
export default function Stats(){
  return <div className="card">
    <h3>Stats</h3>
    <p>View aggregated statistics about your study sessions on the Overview page.</p>
  </div>;
}
