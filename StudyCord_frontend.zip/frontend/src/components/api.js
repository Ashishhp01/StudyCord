import axios from 'axios';
const base = process.env.REACT_APP_API_BASE || 'http://localhost:9000';
export const api = axios.create({ baseURL: base });
export function authHeader(){ const t = localStorage.getItem('jwt_token'); return t ? { Authorization: `Bearer ${t}` } : {}; }
