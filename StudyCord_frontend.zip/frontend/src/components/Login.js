import React, { useState } from 'react';
import { api } from './api';

export default function Login(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');

  async function onSubmit(e){
    e.preventDefault();
    try{
      const { data } = await api.post('/api/users/login',{ email, password });
      localStorage.setItem('jwt_token', data.token);
      setMsg('Logged in');
    }catch(err){ setMsg(err.response?.data?.error || 'Login failed'); }
  }

  return <div className="card">
    <h3>Login</h3>
    <form onSubmit={onSubmit}>
      <label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)} />
      <label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <div style={{marginTop:10}}><button>Login</button></div>
    </form>
    <p>{msg}</p>
  </div>;
}
