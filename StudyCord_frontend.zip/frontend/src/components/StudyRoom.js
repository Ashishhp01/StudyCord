import React, { useEffect, useState } from 'react';
import { api, authHeader } from './api';

export default function StudyRoom(){
  const [title,setTitle]=useState('Reading');
  const [durationMins,setDuration]=useState(25);
  const [list,setList]=useState([]);
  const [msg,setMsg]=useState('');

  async function fetchAll(){
    try{
      const { data } = await api.get('/api/study', { headers: authHeader() });
      setList(data);
    }catch(err){ setMsg('Login required'); }
  }

  useEffect(()=>{ fetchAll(); },[]);

  async function create(){
    try{
      await api.post('/api/study', { title, durationMins }, { headers: authHeader() });
      setTitle('Reading'); setDuration(25);
      fetchAll();
    }catch(err){ setMsg('Create failed'); }
  }

  async function remove(id){
    await api.delete('/api/study/'+id, { headers: authHeader() });
    fetchAll();
  }

  return <div className="card">
    <h3>Study Room</h3>
    <div className="row">
      <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} />
      <input type="number" value={durationMins} onChange={e=>setDuration(+e.target.value)} />
      <button onClick={create}>Add</button>
    </div>
    <ul>
      {list.map(s => <li key={s._id}>
        {s.title} — {s.durationMins} mins
        <button style={{marginLeft:8}} onClick={()=>remove(s._id)}>Delete</button>
      </li>)}
    </ul>
    <p style={{color:'#d00'}}>{msg}</p>
  </div>;
}
