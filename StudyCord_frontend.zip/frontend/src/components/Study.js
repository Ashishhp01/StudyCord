import React, { useEffect, useState } from 'react';
import { api, authHeader } from './api';

export default function Study(){
  const [today,setToday]=useState(0);
  const [stats,setStats]=useState({ sessions: 0, totalMinutes: 0 });
  const [msg,setMsg]=useState('');

  useEffect(()=>{
    async function load(){
      try{
        const h = { headers: authHeader() };
        const t = await api.get('/api/study/today', h);
        setToday(t.data.minutes || 0);
        const s = await api.get('/api/study/stats', h);
        setStats(s.data);
      }catch(err){ setMsg('Login required for stats'); }
    }
    load();
  },[]);

  return <div className="card">
    <h3>Study Overview</h3>
    <p>Studied Today: <b>{today}</b> minutes</p>
    <p>Total Sessions: <b>{stats.sessions}</b>, Total Minutes: <b>{stats.totalMinutes}</b></p>
    <p style={{color:'#d00'}}>{msg}</p>
  </div>;
}
