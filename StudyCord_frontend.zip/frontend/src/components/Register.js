import React, { useState } from 'react';
import { api } from './api';

export default function Register(){
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [msg,setMsg]=useState('');

  async function onSubmit(e){
    e.preventDefault();
    try{
      const { data } = await api.post('/api/users/register',{ name, email, password });
      setMsg(data.message || 'Registered! Check email for verification token.');
    }catch(err){ setMsg(err.response?.data?.error || 'Register failed'); }
  }

  return <div className="card">
    <h3>Register</h3>
    <form onSubmit={onSubmit}>
      <label>Name</label><input value={name} onChange={e=>setName(e.target.value)} />
      <label>Email</label><input value={email} onChange={e=>setEmail(e.target.value)} />
      <label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <div style={{marginTop:10}}><button>Register</button></div>
    </form>
    <p>{msg}</p>
  </div>;
}
