import React, { useState } from 'react';
import { api } from './api';

export default function Verify(){
  const [token,setToken]=useState('');
  const [msg,setMsg]=useState('');

  async function onSubmit(e){
    e.preventDefault();
    try{
      const { data } = await api.post('/api/users/verify',{ token });
      setMsg(data.message || 'Verified');
    }catch(err){ setMsg(err.response?.data?.error || 'Verify failed'); }
  }

  return <div className="card">
    <h3>Email Verification</h3>
    <form onSubmit={onSubmit}>
      <label>Verification Token</label><input value={token} onChange={e=>setToken(e.target.value)} />
      <div style={{marginTop:10}}><button>Verify</button></div>
    </form>
    <p>{msg}</p>
  </div>;
}
