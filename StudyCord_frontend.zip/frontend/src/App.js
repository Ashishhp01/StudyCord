import React from 'react';
import { Routes, Route, Link, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Verify from './components/Verify';
import Study from './components/Study';
import StudyRoom from './components/StudyRoom';
import Stats from './components/Stats';

export default function App(){
  return (
    <div className="container">
      <nav className="nav">
        <Link to="/">Study</Link>
        <Link to="/room">StudyRoom</Link>
        <Link to="/stats">Stats</Link>
        <span style={{flex:1}} />
        <Link to="/login">Login</Link>
        <Link to="/register">Register</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Study />} />
        <Route path="/room" element={<StudyRoom />} />
        <Route path="/stats" element={<Stats />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/verify" element={<Verify />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  );
}
